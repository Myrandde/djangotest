from django.db import models

# Create your models here.

class Citizen(models.Model):
    name = models.CharField(max_length=255)

class Image(models.Model):
    link = models.CharField(max_length=255)
    citizen = models.ForeignKey(Citizen, on_delete=models.CASCADE)

class Detail(models.Model):
    article_id = models.IntegerField()
    citizen = models.ForeignKey(Citizen, on_delete=models.CASCADE, related_name='details')
    gender = models.CharField(max_length=1, choices=[('M', 'Male'), ('F', 'Female')])
    father = models.ForeignKey(Citizen, on_delete=models.CASCADE, related_name='father_details', null=True, blank=True)
    mother = models.ForeignKey(Citizen, on_delete=models.CASCADE, related_name='mother_details', null=True, blank=True)
